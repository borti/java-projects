
package pkg21042023;

/**
 *
 * @author simonebortot
 */


public class Queens 
{
    
    public static int numeroDiSoluzioni( int n ) {
        
        return numeroDiCompletamenti( new Board(n) );
    }
    
    private static int numeroDiCompletamenti( Board b ) {
        
        int n = b.size();       //dimensioni della scacchiera
        int q = b.queensOn();   //numero di regine
        
        if ( q == n ) // caso base
        {
            return 1;  
        } else 
        {
            int i = q + 1;
            int count = 0;
            
            for ( int j=1; j<=n; j=j+1 ) 
            {
                if ( !b.underAttack(i,j) ) 
                {
                    count += numeroDiCompletamenti( b.AddQueen(i,j) );
                }
            }
            return count;
        }
    }
    
    public static SList<Board> listaDiSoluzioni( int n ) {
        
        return listaDiCompletamenti( new Board(n) );
    }
    
    private static SList<Board> listaDiCompletamenti( Board b ) {
        
        int n = b.size();
        int q = b.queensOn();
        
        if ( q == n ) {
            
            return SList.NULL_INTLIST.cons( b );
            
        } else {
            
            int i = q + 1;
            SList<Board> list = SList.NULL_INTLIST;
            
            for ( int j=1; j<=n; j=j+1 ) {
                if ( !b.underAttack(i,j) ) {
                    list = list.append( listaDiCompletamenti(b.AddQueen(i,j)) );
                }
            }
            return list;
        }
    }
    
}  // class Queens


