
package pkg21042023;
import queens.*;

public class Main {

    public static void main(String[] args) 
    {
        Board x = new Board(5);
        System.out.println(x);
        
        
        
        //System.out.println(x.AddQueen(3,4));
        //System.out.println(Queens.numeroDiSoluzioni(5));
        //System.out.println(Queens.listaDiSoluzioni(5));
        

        //queens.ChessboardView view = new queens.ChessboardView( 8 );
        
        //view.setQueens( " b1 e2 g3 d4 a5 h6 f7 c8 " );
        
        Drill.drip(5);   
    }

}
