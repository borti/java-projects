
package pkg21042023;

/**
 *
 * @author simonebortot
 */

import queens.*;



public class Drill {
    
    public static void drip(int n)
    {
        ChessboardView gui= new ChessboardView(n);
        
        SList<Board> soluz = Queens.listaDiSoluzioni(n);
        
        for(int i=0; i<Queens.numeroDiSoluzioni(n); i++)
        {
            Board lean = soluz.listRef(i); // primo elem
            // bisogna prelevare config
            gui.setQueens(lean.arrangement()); // ritorna config
        }
    }
}
