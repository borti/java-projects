
package pkg21042023;

/**
 *
 * @author simonebortot
 */

import queens.*;

public class Board 
{
    private int size;
    private int queens;
    
    private static final String ROWS = " 123456789ABCDEF";
    private static final String COLS = " abcdefghijklmno";
    

    private SList<SList<Integer>> list = new SList();
    
    public final String config; // config delle due regine; composte da un numero e una lettera
    
    public static void drip(int n)
    {
        ChessboardView gui= new ChessboardView(n);
        //gui.setQueens(s);
    }    
    
    public Board(int n)
    {
        size = n;
        queens = 0;
        config = " ";
    }
    public Board(int n, int q, SList<SList<Integer>> list, String c)
    {
        size = n;
        queens = q;
        
        this.list = list;
     
        config = c;
    }
    
    public int size()
    {
        return size;
    }
    
    public int queensOn()
    {
        return queens;
    }
    
    public boolean underAttack(int i, int j)
    {
        boolean isOccupated = false;
        SList<SList<Integer>> temp = list; // lista inizialmente uguale alist che andrò poi a modificare

            while(temp.length()>0)
            {
                SList<Integer> reg = temp.car();  // reg : prima sottolista con le prime coordinate
        
                // u,v sono le coordinate
                int u = reg.car();
                int v = reg.cdr().car();

                for(int x=0; x<queens; x++)
                {
                    if( u == i || v == j || u-v == i-j || u+v == i+j ) 
                    {
                        isOccupated=true;
                    }
                }
                temp = temp.cdr();
            }
        
        return isOccupated;
    }
    
    public Board AddQueen(int i, int j)
    {
        SList<Integer> lol = new SList(i,(SList.NULL_INTLIST.cons(j))); // lista interna con coordinate
        return new Board(
                    size, 
                    queens+1,
                    list.cons(lol), // aggiungi la lista interna alla lista totale
                    config + COLS.charAt(j) + ROWS.charAt(i) + " "
                    );  
    }
    
    public String arrangement()
    {
        return config;
    }
    
    public String toString()
    {
        return " " + arrangement() + " ";
    }
    
}
