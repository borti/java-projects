
package lab;

public class main {
    public static void main(String[] args) 
    {
        Board x = new Board(5);
        System.out.println(x);  // configurazione scacchiera vuota
        
        System.out.println(x.AddQueen(1, 1));
        
        System.out.println(Queens.numeroDiSoluzioni(8));
        System.out.println(Queens.listaDiSoluzioni(8));
        
        
        SList<Integer> l = new SList(1,(SList.NULL_INTLIST.cons(4)));
        System.out.println(l);
    }
    
}
