
package lab;

/**
 *
 * @author simonebortot
 */
public class Board 
{
    private int size;
    private int queens;
    
    private static final String ROWS = " 123456789ABCDEF";
    private static final String COLS = " abcdefghijklmno";
    

    private SList<Integer> righe = new SList();
    private SList<Integer> colonne = new SList();
    private SList<Integer> diag_cresc = new SList();
    private SList<Integer> diag_decresc = new SList();
    
    private final String config; // config delle due regine; composte da un numero e una lettera
    
    public Board(int n)
    {
        size = n;
        queens = 0;
        config = " ";
    }
    public Board(int n, int q, SList<Integer> righe, SList<Integer> colonne, SList<Integer> diag_cresc, SList<Integer> diag_decresc, String c)
    {
        size = n;
        queens = q;
        
        this.righe = righe;
        this.colonne = colonne;
        this.diag_cresc = diag_cresc;
        this.diag_decresc = diag_decresc;
                
        config = c;
    }
    
    public int size()
    {
        return size;
    }
    
    public int queensOn()
    {
        return queens;
    }
    
    public boolean underAttack(int i, int j)
    {
        boolean isOccupated = false;

        for(int x=0; x<queens; x++)
        {
            if( righe.listRef(x) == i || colonne.listRef(x) == j || diag_cresc.listRef(x) == i-j || diag_decresc.listRef(x) == i+j ) 
            {
                isOccupated=true;
            }
        }
        return isOccupated;
    }
    
    public Board AddQueen(int i, int j)
    {
        return new Board(
                    size, 
                    queens+1,
                    righe.cons(i), colonne.cons(j), diag_cresc.cons(i-j), diag_decresc.cons(i+j),
                    config + COLS.charAt(j) + ROWS.charAt(i) + " "
                    );  
    }
    public String arrangement()
    {
        return config;
    }
    
    public String toString()
    {
        return "< " + size + " , " + 
                    queens + " , " +
                    righe  + " , " +
                    colonne + " , " + 
                    diag_cresc + " , " +
                    diag_decresc + " , '" + 
                    arrangement() + "' >";
    }
    
}
