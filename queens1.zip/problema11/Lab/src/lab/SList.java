
package lab;

public class SList<T> {
    private final T first;
    private final SList<T> rest;
    
    // public -> visibile anche al di fuori della classe
    public static final SList NULL_INTLIST = new SList(); // lista vuota
    
    public SList()  // COSTRUTTORE
    {
        first = null;
        rest = null;
    }  
    
    public SList(T first, SList<T> il)  // COSTRUTTORE
    {
        this.first = first;  // scrivendo this.first mi riferisco alla variabile di istanza
                             // se non lo metto significa che mi riferisco al parametro del costruttore
        rest = il;
    } 
    
    public SList(T n)  // COSTRUTTORE
    {
        first = n;
        rest = NULL_INTLIST;
    } 
    
    // posso inizializzare le costanti solo nei costruttori, se lo faccio nei metodi mi da errore!
    
    public boolean isNull() 
    {
        return (first == null);
    }

    public T car()
    {
        return first;
    }

    public SList<T> cdr()
    {
        return rest;
    }

    public SList<T> cons(T n)
    {
        return new SList<T>( n, this );   // "this" si riferisce all'istanza corrente della classe "IntList", 
                                         // ovvero quella sulla quale il metodo "cons" è stato chiamato.
    }
    
    

    /**
     *      sl.length()   : int               |  length
     *      sl.equals(il) : boolean           |  equal
     *      sl.listRef(i) : int               |  list-ref
     *      sl.append(il) : IntList           |  append
     *      sl.reverse()  : IntList           |  reverse
     */

    public int length()
    {
        if(isNull())
        {
            return 0;
        }
        else
        {
            return 1 + cdr().length();
        }
    }
    
    public boolean equals( SList<T> il )
    {
        if( il==null ) // elemento indeterminato
        {
            return false;
        }
        else if(il.isNull())
        {
            return isNull();
        }
        else if(isNull())
        {
            return false;
        }
        else if(il.car() == car())
        {
            return cdr().equals(il.cdr());
        }
        else
        {
            return false;
        }
    }
    
    public SList<T> append(SList<T> il)
    {
        if( isNull() )
        {
            return il;
        }
        else
        {
            return( cdr().append(il) ).cons( car() );
        }
    }
    
    public SList<T> reverse()
    {
        SList rl = new SList<T>(); // lista vuota
        SList sl = this;
        
        while( ! sl.isNull() ){
            rl = rl.cons( sl.car() );
            sl = sl.cdr();
        }
        return rl;
        
        //return reverseRec( NULL_INTLIST ); // versione con ricorsione 
    }

    public T listRef(int e)
    {
        if( e==0 )
        {
            return car();
        }
        else
        {
            return cdr().listRef(e-1);
        }
    }
    
    /*
    public int listRef1(int k)
    {
        // ( 1 , 2 , 3 , 4 , 5 )  lisRef(3) = 2
        
        int i = 0;
        SList temp = this;
        
        if(k>length())
        {
            System.out.println("!!! indice troppo grande !!!");
        }
        while(i < k)
        {
            temp = temp.cdr();
            i++;
        }
        return temp.car();
    }
    
    public int listRef(int k)
    {
        int ref=0;
        if( k<=length())
        {
            if(k==0)
            {
                ref=car();
            }
            else
            {
                int cont=0;
                SList a = this;
                while(cont<k)
                {
                    a=a.cdr();
                    cont++;
                }
                ref = a.car();
            }
        }
        else
        {System.out.println("ATTENZIONE! INDICE TROPPO GRANDE");}
        
        return ref; 
    }*/
    
    //----------------------------------------
    
    public String toString()
    {
        if( isNull() )
        {
            return "()";
        }
        else
        {
            String txt = "( " + car();
            SList r = cdr();
            
            while( !r.isNull() )
            {
                txt = txt + ", " + r.car();
                r = r.cdr();
            }
            return txt + " )";
        }
    }
    
}
