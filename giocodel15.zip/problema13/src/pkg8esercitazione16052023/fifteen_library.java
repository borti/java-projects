
package pkg8esercitazione16052023;

/**
 *
 * @author simonebortot
 */

import puzzleboard.PuzzleBoard;


public class fifteen_library 
{
    private final int tavoletta[][];
    private final int dim;
    private final PuzzleBoard gui;
    
    public fifteen_library(int dim)
    {
        gui = new PuzzleBoard(dim);
        
        this.dim = dim;
        tavoletta = new int[dim][dim];
        
        
        
        int cont = 1;
        for(int i=1; i<=dim; i++)
        {
            for(int j=1; j<=dim; j++)
            {
                gui.setNumber(i, j, cont);
                
                cont++;
            }
        }
        gui.setNumber(dim, dim, 0);
        gui.clear(dim, dim);
        
        int cont1=0;
        for(int x=0; x<dim; x++)
        {
            for(int y=0; y<dim; y++)
            {
                tavoletta[x][y] = cont1+1;
                cont1++;
            }
        }
        tavoletta[dim-1][dim-1] = 0;
        
    }
    
    public boolean isOrdinato() // scannerizza 1riga, 2riga, 3riga
    {
        int tass = 1;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                if (tavoletta[i][j] != tass) 
                {
                    return false;
                }
                tass++;
            }
        }
        return true;
    }
    
    public boolean isSpostabile(int n) // n numero del tassello
    {
        int i=0;
        int j=0;
        // coordinate del tassello
        for(int a=0; a<dim; a++)
        {
            for(int b=0; b<dim; b++)
            {
                if(tavoletta[a][b] == n)
                {
                    i = a;
                    j = b;
                }
            }
        }
        
        int rigaLacuna=0;
        int colLacuna=0;
        
        // per trovare coordinate della lacuna
        for(int x=0; x<dim; x++)
        {
            for(int y=0; y<dim; y++)
            {
                if(tavoletta[x][y] == 0)
                {
                    rigaLacuna=x;
                    colLacuna=y;
                }
            }
        }

        
        //i,j           coordinate del punto
        //rigaLacuna,   colLacuna coordinate della lacuna
        
        // condizione alternzativa più efficiente
        // if(Math.abs(j-colLacuna) + Math.abs(i-rigaLacuna) == 1)
        
        if( (i == rigaLacuna) && (Math.abs(j-colLacuna) == 1) ) 
        {
            return true;
        }
        else if( (j == colLacuna) && (Math.abs(i-rigaLacuna) == 1) ) 
        {
            return true;
        }
        
        return false;
    }
    
    public String config()
    {
        String s = "";
        for(int i=0; i<dim; i++)
        {
            for(int j=0; j<dim; j++)
            {
                s = s + (String.valueOf(tavoletta[i][j]) + " \t ");
            }
            s = s + "\n";
        }
        return s;
    }
    
    public void fincCoord()
    {
        while(true)
        {
            int k = gui.get();
            System.out.println(k);
            int i = 0;
            int j = 0;

            for(int x=0; x<dim; x++)
            {
                for(int y=0; y<dim; y++)
                {
                    if(tavoletta[x][y] == k)
                    {
                        i=x;
                        j=y;
                    }
                }
            }
            System.out.println(i+" "+j);
        }
        
    }
    
    public void clickTass()
    {
        while(true)
        {
            int k = gui.get();
            System.out.println(k);
            
            int i=0;
            int j=0;
            for(int x=0; x<dim; x++)
            {
                for(int y=0; y<dim; y++)
                {
                    if(tavoletta[x][y] == k)   // da rivedere perchè aggiunge 17 nella config
                    {
                        i=x+1;
                        j=y+1;
                    }
                }
            }
            System.out.println(i+" "+j);
            
            int rigaLacuna=0;
            int colLacuna=0;
            
            for(int x=0; x<dim; x++)
            {
                for(int y=0; y<dim; y++)
                {
                    if(tavoletta[x][y] == 0)
                    {
                        rigaLacuna=x+1;
                        colLacuna=y+1;
                    }
                }
            }
            // System.out.println(rigaLacuna + " " +colLacuna);
            gui.setNumber(rigaLacuna, colLacuna, k);            
        }
    }
    
    public void MoveTass()  
    {
        while(true)
        {
            int k = gui.get();

            if(isSpostabile(k))
            {
                int i=0;
                int j=0;
                for(int x=0; x<dim; x++)
                {
                    for(int y=0; y<dim; y++)
                    {
                        if(tavoletta[x][y] == k)   // da rivedere perchè aggiunge 17 nella config
                        {
                            i=x+1;
                            j=y+1;
                        }
                    }
                }
                
                int rigaLacuna=0;
                int colLacuna=0;

                for(int x=0; x<dim; x++)
                {
                    for(int y=0; y<dim; y++)
                    {
                        if(tavoletta[x][y] == 0)
                        {
                            rigaLacuna=x+1;
                            colLacuna=y+1;
                        }
                    }
                }
                System.out.println(config());
                gui.setNumber(rigaLacuna, colLacuna, k);
                gui.clear(i,j);
                
                tavoletta[rigaLacuna-1][colLacuna-1] = tavoletta[i-1][j-1];
                tavoletta[i-1][j-1] = 0;
                
            }  
        }
    } 
}
