
package pkg8esercitazione16052023;

/**
 *
 * @author simonebortot
 */


public class Main {
    public static void main(String[] args) 
    {
        //PuzzleBoard gui = new PuzzleBoard( 4 );
        fifteen a = new fifteen(4);
        System.out.println(a.config());
        System.out.println(a.isOrdinato());
        System.out.println(a.isSpostabile(15));
        
        fifteen_library b = new fifteen_library(4);
        
        System.out.println(b.config());
        //b.clickTass();
        //b.fincCoord();
        b.MoveTass();
        
    }
}
