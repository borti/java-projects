
package pkg8esercitazione16052023;

/**
 *
 * @author simonebortot
 */
public class fifteen 
{
    private int tavoletta[][];
    private int dim;
    
    public fifteen(int dim)
    {
        this.dim = dim;
        tavoletta = new int[dim][dim];
        
        /*
        int cont = 0;
        for(int i=0; i<dim; i++)
        {
            for(int j=0; j<dim; j++)
            {
                tavoletta[i][j] = cont+1;
                cont++;
            }
        }
        tavoletta[dim-1][dim-1] = 0;*/
        inizialize(dim, tavoletta);
        
    }
    
    public void inizialize(int dim, int mat[][])
    {
        int cont = 0;
        for(int i=0; i<dim; i++)
        {
            for(int j=0; j<dim; j++)
            {
                tavoletta[i][j] = cont+1;
                cont++;
            }
        }
        tavoletta[dim-1][dim-1] = 0;
    }
    
    public boolean isOrdinato() // scannerizza 1riga, 2riga, 3riga
    {
        int tass = 1;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                if (tavoletta[i][j] != tass) 
                {
                    return false;
                }
                tass++;
            }
        }
        return true;
    }
    
    public boolean isSpostabile(int n) // n numero del tassello
    {
        int i=0;
        int j=0;
        // coordinate del tassello
        for(int a=0; a<dim; a++)
        {
            for(int b=0; b<dim; b++)
            {
                if(tavoletta[a][b] == n)
                {
                    i = a;
                    j = b;
                }
            }
        }
        
        int rigaLacuna=0;
        int colLacuna=0;
        
        // per trovare coordinate della lacuna
        for(int x=0; x<dim; x++)
        {
            for(int y=0; y<dim; y++)
            {
                if(tavoletta[x][y] == 0)
                {
                    rigaLacuna=x;
                    colLacuna=y;
                }
            }
        }

        
        //i,j           coordinate del punto
        //rigaLacuna,   colLacuna coordinate della lacuna
        
        // condizione alternzativa più efficiente
        // if(Math.abs(j-colLacuna) + Math.abs(i-rigaLacuna) == 1)
        
        if( (i == rigaLacuna) && (Math.abs(j-colLacuna) == 1) ) 
        {
            return true;
        }
        else if( (j == colLacuna) && (Math.abs(i-rigaLacuna) == 1) ) 
        {
            return true;
        }
        
        return false;
    }
    
    public String config()
    {
        String s = "";
        for(int i=0; i<dim; i++)
        {
            for(int j=0; j<dim; j++)
            {
                s = s + (String.valueOf(tavoletta[i][j]) + "\t");
            }
            s = s + " \n";
        }
        return s;
    }
    
    public void MoveTass(int n)  // int[][]
    {
        // mi ricavo le coordinate di n
        // mi ricavo le coordinate della lacuna 
        // coordinate n = coordinate lacuna
        if(isSpostabile(n))
        {
            int i=0;
            int j=0;
            for(int a=0; a<dim; a++)
            {
                for(int b=0; b<dim; b++)
                {
                    if(tavoletta[a][b] == n)
                    {
                        i = a;
                        j = b;
                    }
                }
            }
            
            int rigaLacuna=0;
            int colLacuna=0;

            // per trovare coordinate della lacuna
            for(int x=0; x<dim; x++)
            {
                for(int y=0; y<dim; y++)
                {
                    if(tavoletta[x][y] == 0)
                    {
                        rigaLacuna=x;
                        colLacuna=y;
                    }
                }
            }
            
            tavoletta[rigaLacuna][colLacuna] = tavoletta[i][j];
            tavoletta[i][j] = 0;
        }
    }
    
    
}
