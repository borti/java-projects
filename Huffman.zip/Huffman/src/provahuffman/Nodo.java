
package provahuffman;

/**
 *
 * @author simonebortot
 */
public class Nodo implements Comparable<Nodo>{

    private final char simbolo;
    private final int peso;
    private final Nodo sx;
    private final Nodo dx;

    public Nodo(char c, int w) {
        simbolo = c;
        peso = w;
        sx = null;
        dx = null;
    }

    public Nodo(Nodo l, Nodo r) {
        simbolo = (char) 0;
        peso = l.peso() + r.peso();
        sx = l;
        dx = r;
    }

    public boolean foglia() {
        return (sx == null);
    }

    public char simbolo() {
        return simbolo;
    }

    public int peso() {
        return peso;
    }

    public Nodo sinistro() {
        return sx;
    }

    public Nodo destro() {
        return dx;
    }

    public int compareTo(Nodo altro) {
        if (peso < altro.peso()) {
            return -1;
        } else if (peso == altro.peso()) {
            return 0;
        } else {
            return 1;
        }
    }

}

