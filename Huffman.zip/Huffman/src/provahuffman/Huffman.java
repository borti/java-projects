
package provahuffman;

import java.util.PriorityQueue;
import java.util.Stack;
import huffman_toolkit.*;

/**
 *
 * @author simonebortot
 */
public class Huffman {

    public static void main(String[] args) {
        comprimi("original", "compressed");
        decomprimi("compressed", "decompressed");
    }

    public static void comprimi(String src, String dst) {
        int[] freq = freqCar(src);
        Nodo radice = alberoHuffman(freq);
        String[] tab = tabHuffman(radice);

        InputTextFile in = new InputTextFile(src);
        OutputTextFile out = new OutputTextFile(dst);

        out.writeTextLine(""+radice.peso());
        out.writeTextLine(codificaAlberoIter(radice));

        while(in.textAvailable()) {

            char c = in.readChar();
            out.writeCode(tab[c]);
        }

        in.close();
        out.close();
    }

    public static void decomprimi(String src, String dst) {

        InputTextFile in = new InputTextFile(src);
        OutputTextFile out = new OutputTextFile(dst);

        int conto = Integer.parseInt(in.readTextLine());
        Nodo radice = ripristinaAlbero(in);

        String dummy = in.readTextLine();

        for (int i = 0; i < conto; i++) {
            Nodo n = radice;

            do {
                int bit = in.readBit();
                n = (bit == 0) ? n.sinistro() : n.destro();
            } while (!n.foglia());

            char c = n.simbolo();
            out.writeChar(c);
        }
        in.close();
        out.close();
    }

    private static String codificaAlbero(Nodo nodo) {
        if (nodo.foglia()) {
            char c = nodo.simbolo();

            if ((c == '@') || (c == '\\')) {
                return "\\" + c;
            } else {
                return "" + c;
            }

        } else {
            return "@" + codificaAlbero(nodo.sinistro()) +
                         codificaAlbero(nodo.destro());
        }
    }

    private static String codificaAlberoIter(Nodo radice) {
        Stack<Nodo> stack = new Stack<Nodo>();
        stack.push(radice);

        String codifica = "";

        do {
            Nodo nodo = stack.pop();

            if (nodo.foglia()) {
                char c = nodo.simbolo();

                if ((c == '@') || (c == '\\')) {
                    codifica += "\\" + c;
                } else {
                    codifica += c;
                }

            } else {
                codifica += "@";

                stack.push(nodo.destro());
                stack.push(nodo.sinistro());
            }
        } while (!stack.empty());

        return codifica;
    }

    private static Nodo ripristinaAlbero(InputTextFile in) {
        char c = in.readChar();

        if (c == '@') {
            // Nodo intermedio
            Nodo l = ripristinaAlbero(in);
            Nodo r = ripristinaAlbero(in);
            return new Nodo(l, r);
        } else { // Carattere
            if (c == '\\') {
                c = in.readChar();
            }
            return new Nodo(c, 0);
        }
    }

    private static int[] freqCar(String src) {
        InputTextFile in = new InputTextFile(src);

        int[] conto = new int[InputTextFile.CHARS];

        for (int i = 0; i < conto.length; i++) {
            conto[i] = 0;
        }

        while (in.textAvailable()) {

            char c = in.readChar();
            conto[c]++;
        }

        in.close();

        return conto;
    }

    private static Nodo alberoHuffman(int[] freq) {
        PriorityQueue<Nodo> coda = new PriorityQueue<Nodo>();

        for(int c = 0; c < freq.length; c++) {
            if (freq[c] > 0) {
                Nodo nodo = new Nodo((char) c, freq[c]);
                coda.add(nodo);
            }
        }

        while (coda.size() > 1) {
            Nodo l = coda.poll();
            Nodo r = coda.poll();

            Nodo rad= new Nodo(l, r);
            coda.add(rad);
        }

        return coda.poll();
    }

    private static String[] tabHuffman(Nodo rad) {
        String[] tab = new String[InputTextFile.CHARS];

        compilaTab(rad, "", tab);

        return tab;
    }

    private static void compilaTab(Nodo n, String cod, String[] tab) {
        if (n.foglia()) {
            tab[n.simbolo()] = cod;
        } else {
            compilaTab(n.sinistro(), cod + "0", tab);
            compilaTab(n.destro(), cod + "1", tab);
        }
    }

}

