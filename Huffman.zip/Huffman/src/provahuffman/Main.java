
package provahuffman;

/**
 *
 * @author simonebortot
 */
public class Main {
    public static void main(String[] args) 
    {
        String fileOriginale="/Users/simonebortot/Desktop/provaHuffman/string.txt";
        String temp="/Users/simonebortot/Desktop/provaHuffman/compress.txt";
        String finals="/Users/simonebortot/Desktop/provaHuffman/decompress.txt";
        
        Huffman.comprimi(fileOriginale, temp);
        Huffman.decomprimi(temp, finals);
    }
    
}
